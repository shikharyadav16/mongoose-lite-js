import { AnyObject, FilterQuery, UpdateQuery } from "../types/common.types.js";
type SchemaType = {
    definition: Record<string, any>;
    hooks: Record<"pre" | "post", Record<string, Function[]>>;
};
type ConnectionType = {
    path: string;
};
export declare function createModel<T extends AnyObject>(name: string, schema: SchemaType, connection: ConnectionType): {
    name: string;
    schema: SchemaType;
    connection: ConnectionType;
    save: (doc: T) => Promise<T & {
        _id: string;
    }>;
    create: (doc: T) => Promise<T & {
        _id: string;
    }>;
    find: (filter?: FilterQuery<T>) => Promise<T[]>;
    findOne: (filter?: FilterQuery<T>) => Promise<T | null>;
    findById: (_id: string) => Promise<T | null>;
    deleteOne: (filter?: FilterQuery<T>) => Promise<{
        deletedCount: number;
    }>;
    deleteMany: (filter?: FilterQuery<T>) => Promise<{
        deletedCount: number;
    }>;
    updateOne: (filter: FilterQuery<T> | undefined, doc: UpdateQuery<T>) => Promise<{
        matchedCount: number;
    }>;
    updateMany: (filter: FilterQuery<T> | undefined, doc: UpdateQuery<T>) => Promise<{
        matchedCount: number;
    }>;
    countDocuments: (filter?: FilterQuery<T>) => Promise<number>;
    exists: (filter?: FilterQuery<T>) => Promise<boolean>;
};
export {};
//# sourceMappingURL=Model.d.ts.map