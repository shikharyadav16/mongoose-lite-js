"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createModel = createModel;
const path_1 = __importDefault(require("path"));
const DBHelper_js_1 = require("../db/DBHelper.js");
const validation_js_1 = require("../validations/validation.js");
const ValidationError_js_1 = require("../errors/ValidationError.js");
function createModel(name, schema, connection) {
    if (!connection?.path) {
        throw new Error("Connect mongoose before making a model.");
    }
    const schemaCheck = (0, validation_js_1.validateSchema)(schema.definition);
    if (!schemaCheck.valid) {
        throw new ValidationError_js_1.ValidationError(schemaCheck.errors);
    }
    const filePath = path_1.default.join(connection.path, `${name.toLowerCase()}.yaml`);
    async function runHooks(type, key, payload) {
        const hooks = schema.hooks?.[type]?.[key];
        if (hooks) {
            for (const fn of hooks) {
                await fn(payload);
            }
        }
    }
    async function save(doc) {
        await runHooks("pre", "save", doc);
        const res = DBHelper_js_1.DBHelper.insert(doc, schema, filePath);
        await runHooks("post", "save", res);
        return res;
    }
    async function create(doc) {
        await runHooks("pre", "create", doc);
        const res = DBHelper_js_1.DBHelper.insert(doc, schema, filePath);
        await runHooks("post", "create", res);
        return res;
    }
    async function find(filter = {}) {
        await runHooks("pre", "find");
        const res = DBHelper_js_1.DBHelper.find(filter, filePath);
        await runHooks("post", "find", res);
        return res;
    }
    async function findOne(filter = {}) {
        await runHooks("pre", "findOne");
        const res = DBHelper_js_1.DBHelper.findOne(filter, filePath);
        await runHooks("post", "findOne", res);
        return res;
    }
    async function findById(_id) {
        if (typeof _id !== "string")
            throw new Error("Invalid ObjectId");
        const filter = { _id };
        await runHooks("pre", "findById");
        const res = DBHelper_js_1.DBHelper.findOne(filter, filePath);
        await runHooks("post", "findById", res);
        return res;
    }
    async function deleteOne(filter = {}) {
        await runHooks("pre", "deleteOne");
        const res = DBHelper_js_1.DBHelper.delete(filter, schema, filePath, false);
        await runHooks("post", "deleteOne", res);
        return res;
    }
    async function deleteMany(filter = {}) {
        await runHooks("pre", "deleteMany");
        const res = DBHelper_js_1.DBHelper.delete(filter, schema, filePath, true);
        await runHooks("post", "deleteMany", res);
        return res;
    }
    async function updateOne(filter = {}, doc) {
        await runHooks("pre", "updateOne");
        const res = DBHelper_js_1.DBHelper.update(filter, doc, filePath);
        await runHooks("post", "updateOne", res);
        return res;
    }
    async function updateMany(filter = {}, doc) {
        await runHooks("pre", "updateMany");
        const res = DBHelper_js_1.DBHelper.update(filter, doc, filePath);
        await runHooks("post", "updateMany", res);
        return res;
    }
    async function countDocuments(filter = {}) {
        await runHooks("pre", "countDocuments");
        const res = DBHelper_js_1.DBHelper.count(filter, schema, filePath);
        await runHooks("post", "countDocuments", res);
        return res;
    }
    async function exists(filter = {}) {
        await runHooks("pre", "exists");
        const res = DBHelper_js_1.DBHelper.exists(filter, schema, filePath);
        await runHooks("post", "exists", res);
        return res;
    }
    return {
        name,
        schema,
        connection,
        save,
        create,
        find,
        findOne,
        findById,
        deleteOne,
        deleteMany,
        updateOne,
        updateMany,
        countDocuments,
        exists
    };
}
//# sourceMappingURL=Model.js.map