import { Schema } from "./Schema.js";
import type { IConnection } from "../db/Connection.js";
interface IMongoose {
    connections: IConnection[];
}
export default class Mongoose implements IMongoose {
    connections: IConnection[];
    connect(path: string): IConnection;
    Schema<T extends Record<string, any>>(definition: T, options?: Record<string, any>): Schema<T>;
    model<T extends Record<string, any>>(name: string, schema: Schema<T>, connection?: IConnection): {
        name: string;
        schema: {
            definition: Record<string, any>;
            hooks: Record<"pre" | "post", Record<string, Function[]>>;
        };
        connection: {
            path: string;
        };
        save: (doc: T) => Promise<T & {
            _id: string;
        }>;
        create: (doc: T) => Promise<T & {
            _id: string;
        }>;
        find: (filter?: Partial<{ [k in keyof T]: T[k] | {
            $in?: T[k][];
            $gt?: T[k];
            $lt?: T[k];
            $eq?: T[k];
        }; }>) => Promise<T[]>;
        findOne: (filter?: Partial<{ [k in keyof T]: T[k] | {
            $in?: T[k][];
            $gt?: T[k];
            $lt?: T[k];
            $eq?: T[k];
        }; }>) => Promise<T | null>;
        findById: (_id: string) => Promise<T | null>;
        deleteOne: (filter?: Partial<{ [k in keyof T]: T[k] | {
            $in?: T[k][];
            $gt?: T[k];
            $lt?: T[k];
            $eq?: T[k];
        }; }>) => Promise<{
            deletedCount: number;
        }>;
        deleteMany: (filter?: Partial<{ [k in keyof T]: T[k] | {
            $in?: T[k][];
            $gt?: T[k];
            $lt?: T[k];
            $eq?: T[k];
        }; }>) => Promise<{
            deletedCount: number;
        }>;
        updateOne: (filter: Partial<{ [k in keyof T]: T[k] | {
            $in?: T[k][];
            $gt?: T[k];
            $lt?: T[k];
            $eq?: T[k];
        }; }> | undefined, doc: import("../types/common.types.js").UpdateQuery<T>) => Promise<{
            matchedCount: number;
        }>;
        updateMany: (filter: Partial<{ [k in keyof T]: T[k] | {
            $in?: T[k][];
            $gt?: T[k];
            $lt?: T[k];
            $eq?: T[k];
        }; }> | undefined, doc: import("../types/common.types.js").UpdateQuery<T>) => Promise<{
            matchedCount: number;
        }>;
        countDocuments: (filter?: Partial<{ [k in keyof T]: T[k] | {
            $in?: T[k][];
            $gt?: T[k];
            $lt?: T[k];
            $eq?: T[k];
        }; }>) => Promise<number>;
        exists: (filter?: Partial<{ [k in keyof T]: T[k] | {
            $in?: T[k][];
            $gt?: T[k];
            $lt?: T[k];
            $eq?: T[k];
        }; }>) => Promise<boolean>;
    };
}
export {};
//# sourceMappingURL=Mongoose.d.ts.map