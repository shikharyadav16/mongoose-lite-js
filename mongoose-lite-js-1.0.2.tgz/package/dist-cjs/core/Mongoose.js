"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Connection_js_1 = require("../db/Connection.js");
const Schema_js_1 = require("./Schema.js");
const Model_js_1 = require("./Model.js");
class Mongoose {
    connections = [];
    connect(path) {
        const conn = (0, Connection_js_1.createConnection)(path);
        this.connections.push(conn);
        console.log("[DB] Connected →", conn.path);
        return conn;
    }
    Schema(definition, options = {}) {
        return (0, Schema_js_1.createSchema)(definition, options);
    }
    model(name, schema, connection) {
        const conn = connection || this.connections[0];
        if (!conn) {
            throw new Error("No active connection. Call connect() first.");
        }
        return (0, Model_js_1.createModel)(name, schema, conn);
    }
}
exports.default = Mongoose;
//# sourceMappingURL=Mongoose.js.map