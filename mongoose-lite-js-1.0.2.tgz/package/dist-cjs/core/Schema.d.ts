type HookType = "pre" | "post";
type OperationType = string;
type MethodFunction<T = any> = (this: T, ...args: any[]) => any;
type HookFunction<T = any> = (doc: T) => void | Promise<void>;
type SchemaDefinition<T> = {
    [k in keyof T]: any;
};
type SchemaOptions = Record<string, any>;
export declare class Schema<T = any> {
    definition: SchemaDefinition<T>;
    options: SchemaOptions;
    virtuals: Record<string, (this: T) => any>;
    statics: Record<string, MethodFunction>;
    methods: Record<string, MethodFunction<T>>;
    hooks: Record<HookType, Record<OperationType, HookFunction<T>[]>>;
    constructor(definition: SchemaDefinition<T>, options?: SchemaOptions);
    addMethod(name: string, fn: MethodFunction<T>): void;
    addStatic(name: string, fn: MethodFunction): void;
    addHook(type: HookType, operation: OperationType, fn: HookFunction<T>): void;
    pre(operation: OperationType, fn: HookFunction<T>): void;
    post(operation: OperationType, fn: HookFunction<T>): void;
}
export declare function createSchema<T>(definition: SchemaDefinition<T>, options?: SchemaOptions): Schema<T>;
export {};
//# sourceMappingURL=Schema.d.ts.map