"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Schema = void 0;
exports.createSchema = createSchema;
class Schema {
    definition;
    options;
    virtuals = {};
    statics = {};
    methods = {};
    hooks = { pre: {}, post: {} };
    constructor(definition, options = {}) {
        this.definition = definition;
        this.options = options;
    }
    addMethod(name, fn) {
        this.methods[name] = fn;
    }
    addStatic(name, fn) {
        this.statics[name] = fn;
    }
    addHook(type, operation, fn) {
        if (!this.hooks[type][operation]) {
            this.hooks[type][operation] = [];
        }
        this.hooks[type][operation].push(fn);
    }
    pre(operation, fn) {
        this.addHook("pre", operation, fn);
    }
    post(operation, fn) {
        this.addHook("post", operation, fn);
    }
}
exports.Schema = Schema;
function createSchema(definition, options = {}) {
    return new Schema(definition, options);
}
//# sourceMappingURL=Schema.js.map