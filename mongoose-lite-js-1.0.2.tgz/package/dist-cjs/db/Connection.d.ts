export interface IConnection {
    path: string;
    state: "connected" | "disconnected";
    connectedAt: Date;
}
export declare class Connection implements IConnection {
    path: string;
    state: "connected" | "disconnected";
    connectedAt: Date;
    constructor(dbPath: string);
    disconnect(): void;
}
export declare function createConnection(dbPath: string): Connection;
//# sourceMappingURL=Connection.d.ts.map