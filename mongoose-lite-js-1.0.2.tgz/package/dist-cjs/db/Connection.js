"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Connection = void 0;
exports.createConnection = createConnection;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
class Connection {
    path;
    state;
    connectedAt;
    constructor(dbPath) {
        this.path = path_1.default.join(process.cwd(), dbPath);
        if (!fs_1.default.existsSync(this.path))
            fs_1.default.mkdirSync(this.path, { recursive: true });
        this.state = "connected";
        this.connectedAt = new Date();
    }
    disconnect() {
        this.state = "disconnected";
    }
}
exports.Connection = Connection;
function createConnection(dbPath) {
    return new Connection(dbPath);
}
//# sourceMappingURL=Connection.js.map