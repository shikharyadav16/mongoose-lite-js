import { AnyObject, FilterQuery, UpdateQuery } from "../types/common.types.js";
type SchemaDefinition = Record<string, any>;
type WithId<T> = T & {
    _id: string;
};
export declare const DBHelper: {
    insert<T extends AnyObject>(doc: T, schema: {
        definition: SchemaDefinition;
    }, filePath: string): WithId<T>;
    find<T extends AnyObject>(filter: FilterQuery<T>, filePath: string): T[];
    findOne<T extends AnyObject>(filter: FilterQuery<T>, filePath: string): T | null;
    update<T extends AnyObject>(filter: FilterQuery<T>, update: UpdateQuery<T>, filePath: string): {
        matchedCount: number;
    };
    delete<T extends AnyObject>(filter: FilterQuery<T>, schema: {
        definition: SchemaDefinition;
    }, filePath: string, multiple?: boolean): {
        deletedCount: number;
    };
    count<T extends AnyObject>(filter: FilterQuery<T>, schema: {
        definition: SchemaDefinition;
    }, filePath: string): number;
    exists<T extends AnyObject>(filter: FilterQuery<T>, schema: {
        definition: SchemaDefinition;
    }, filePath: string): boolean;
};
export {};
//# sourceMappingURL=DBHelper.d.ts.map