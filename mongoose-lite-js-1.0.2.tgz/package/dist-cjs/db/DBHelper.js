"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DBHelper = void 0;
const Types_js_1 = __importDefault(require("../types/Types.js"));
const validation_js_1 = require("../validations/validation.js");
const yamlHelper_js_1 = require("../utils/yamlHelper.js");
const applyDefaults_js_1 = __importDefault(require("../utils/applyDefaults.js"));
const matchFilter_js_1 = __importDefault(require("../utils/matchFilter.js"));
const applyUpdate_js_1 = __importDefault(require("../utils/applyUpdate.js"));
exports.DBHelper = {
    insert(doc, schema, filePath) {
        const resSchema = (0, validation_js_1.validateSchema)(schema.definition);
        if (!resSchema.valid)
            throw new Error(resSchema.errors.join(", "));
        ;
        const existing = (0, yamlHelper_js_1.readFile)(filePath);
        const filtered = (0, applyDefaults_js_1.default)(doc, schema.definition);
        const newDoc = {
            ...filtered,
            _id: Types_js_1.default.ObjectId(),
        };
        existing.push(newDoc);
        (0, yamlHelper_js_1.writeFile)(filePath, existing);
        return newDoc;
    },
    find(filter, filePath) {
        const existing = (0, yamlHelper_js_1.readFile)(filePath);
        return existing.filter(doc => (0, matchFilter_js_1.default)(doc, filter));
    },
    findOne(filter, filePath) {
        const existing = (0, yamlHelper_js_1.readFile)(filePath);
        return existing.find(doc => (0, matchFilter_js_1.default)(doc, filter)) || null;
    },
    update(filter, update, filePath) {
        const existing = (0, yamlHelper_js_1.readFile)(filePath);
        let count = 0;
        for (let i = 0; i < existing.length; i++) {
            const doc = existing[i];
            if (!doc)
                continue;
            if ((0, matchFilter_js_1.default)(doc, filter)) {
                existing[i] = (0, applyUpdate_js_1.default)(doc, update);
                count++;
            }
        }
        (0, yamlHelper_js_1.writeFile)(filePath, existing);
        return { matchedCount: count };
    },
    delete(filter, schema, filePath, multiple = false) {
        let existing = (0, yamlHelper_js_1.readFile)(filePath);
        const originalLength = existing.length;
        if (multiple) {
            existing = existing.filter(doc => !(0, matchFilter_js_1.default)(doc, filter));
        }
        else {
            const index = existing.findIndex(doc => (0, matchFilter_js_1.default)(doc, filter));
            if (index !== -1) {
                existing.splice(index, 1);
            }
        }
        (0, yamlHelper_js_1.writeFile)(filePath, existing);
        return { deletedCount: originalLength - existing.length };
    },
    count(filter, schema, filePath) {
        const existing = (0, yamlHelper_js_1.readFile)(filePath);
        return existing.filter(doc => (0, matchFilter_js_1.default)(doc, filter)).length;
    },
    exists(filter, schema, filePath) {
        const existing = (0, yamlHelper_js_1.readFile)(filePath);
        return existing.some(doc => (0, matchFilter_js_1.default)(doc, filter));
    }
};
//# sourceMappingURL=DBHelper.js.map