type ValidationErrorItem = {
    message: string;
    kind: string;
    path: string;
    value: any;
};
export declare class ValidationError extends Error {
    errors: Record<string, ValidationErrorItem>;
    constructor(errorsArray?: string[]);
}
export declare function validationError(errorsArray: string[] | undefined | null): ValidationError | null;
export {};
//# sourceMappingURL=ValidationError.d.ts.map