import Mongoose from "./core/Mongoose.js";
declare const mongoose: Mongoose;
export default mongoose;
export { Mongoose };
//# sourceMappingURL=index.d.ts.map