"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Mongoose = void 0;
const Mongoose_js_1 = __importDefault(require("./core/Mongoose.js"));
exports.Mongoose = Mongoose_js_1.default;
const mongoose = new Mongoose_js_1.default();
exports.default = mongoose;
//# sourceMappingURL=index.js.map