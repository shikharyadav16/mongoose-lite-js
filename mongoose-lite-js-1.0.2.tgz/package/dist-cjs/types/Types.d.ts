declare const Types: {
    ObjectId(): string;
    String: StringConstructor;
    Number: NumberConstructor;
    Boolean: BooleanConstructor;
    Array: ArrayConstructor;
    Object: ObjectConstructor;
    Date: DateConstructor;
};
export default Types;
//# sourceMappingURL=Types.d.ts.map