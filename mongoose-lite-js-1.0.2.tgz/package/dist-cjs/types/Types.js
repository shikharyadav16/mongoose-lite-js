"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const crypto_1 = require("crypto");
const Types = {
    ObjectId() {
        return (0, crypto_1.randomUUID)();
    },
    String: String,
    Number: Number,
    Boolean: Boolean,
    Array: Array,
    Object: Object,
    Date: Date,
};
exports.default = Types;
//# sourceMappingURL=Types.js.map