import { AnyObject } from "../types/common.types.js";
type SchemaDefinition = Record<string, any>;
export default function applyDefaults<T extends AnyObject>(doc: T, schema: SchemaDefinition): T;
export {};
//# sourceMappingURL=applyDefaults.d.ts.map