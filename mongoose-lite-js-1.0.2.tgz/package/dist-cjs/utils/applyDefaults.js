"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = applyDefaults;
function applyDefaults(doc, schema) {
    const result = { ...doc };
    for (const key in schema) {
        const rule = schema[key];
        if (typeof rule === "object" && "default" in rule && result[key] === undefined) {
            result[key] = typeof rule.default === "function" ? rule.default() : rule.default;
        }
    }
    return result;
}
//# sourceMappingURL=applyDefaults.js.map