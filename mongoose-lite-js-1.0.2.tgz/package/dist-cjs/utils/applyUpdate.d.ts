import { AnyObject, UpdateQuery } from "../types/common.types.js";
export default function applyUpdate<T extends AnyObject>(doc: T, update: UpdateQuery<T>): T;
//# sourceMappingURL=applyUpdate.d.ts.map