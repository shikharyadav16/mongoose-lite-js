"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = applyUpdate;
function applyUpdate(doc, update) {
    const newDoc = { ...doc };
    if (!Object.keys(update).some((k) => k.startsWith("$"))) {
        Object.assign(newDoc, update);
        return newDoc;
    }
    if (update.$set) {
        Object.assign(newDoc, update.$set);
    }
    if (update.$max) {
        for (const key in update.$max) {
            const val = update.$max[key];
            if (val !== undefined && newDoc[key] < val) {
                newDoc[key] = val;
            }
        }
    }
    if (update.$min) {
        for (const key in update.$min) {
            const val = update.$min[key];
            if (val !== undefined && newDoc[key] > val) {
                newDoc[key] = val;
            }
        }
    }
    if (update.$push) {
        for (const key in update.$push) {
            if (!Array.isArray(newDoc[key])) {
                newDoc[key] = [];
            }
            newDoc[key].push(update.$push[key]);
        }
    }
    if (update.$pull) {
        for (const key in update.$pull) {
            if (Array.isArray(newDoc[key])) {
                newDoc[key] = newDoc[key].filter(item => item !== update.$pull[key]);
            }
        }
    }
    return newDoc;
}
//# sourceMappingURL=applyUpdate.js.map