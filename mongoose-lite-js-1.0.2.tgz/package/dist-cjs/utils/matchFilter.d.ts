import { AnyObject, FilterQuery } from "../types/common.types.js";
export default function matchFilter<T extends AnyObject>(doc: T, filter: FilterQuery<T>): boolean;
//# sourceMappingURL=matchFilter.d.ts.map