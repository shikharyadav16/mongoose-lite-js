"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = matchFilter;
function matchFilter(doc, filter) {
    for (const key in filter) {
        const val = filter[key];
        const docValue = doc[key];
        if (typeof val === "object" && val !== null) {
            const op = val;
            if (op.$in && !op.$in.includes(docValue))
                return false;
            if (op.$gt !== undefined) {
                if (!(docValue > op.$gt))
                    return false;
            }
            if (op.$lt !== undefined) {
                if (!(docValue < op.$lt))
                    return false;
            }
            if (op.$eq !== undefined) {
                if (!(docValue === op.$eq))
                    return false;
            }
        }
        else {
            if (docValue !== val)
                return false;
        }
    }
    return true;
}
//# sourceMappingURL=matchFilter.js.map