export declare function readFile<T = any>(filePath: string): T[];
export declare function writeFile<T>(filePath: string, data: T[]): void;
//# sourceMappingURL=yamlHelper.d.ts.map