type ValidationResult = {
    valid: true;
} | {
    valid: false;
    errors: string[];
};
type SchemaDefinition = Record<string, any>;
export declare function validateData(data: any, schema: SchemaDefinition): ValidationResult;
export declare function validateSchema(schema: SchemaDefinition, path?: string): ValidationResult;
export declare function validateModelName(name: string): ValidationResult;
export {};
//# sourceMappingURL=validation.d.ts.map